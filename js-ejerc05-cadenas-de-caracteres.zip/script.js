var nombre = "Emilio ";
var apellido = "Martínez López";
var primera_letra = nombre[0];

document.write("<p> Las variables nombre y apellidos concatenadas resultan en: ",nombre + apellido,"</p>")
document.write("<p> La primera letra de mi nombre es:" ,primera_letra, "</p>")
