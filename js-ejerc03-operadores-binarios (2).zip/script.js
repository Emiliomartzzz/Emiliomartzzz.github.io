A=prompt("Escribe un número entero A","10");
B=prompt("Escribe otro número entero B", "20");
var A=10;
var B=20;
var multiplica= A*B;
var divide= A/B;
var suma= A+B;
var resta= A-B;
document.write("<p>El resultado de dividir ",A, " entre ",B, " es ",divide,"</p>")
document.write("<p>El resultado de multiplicar ",A," más ",B, " es ",multiplica,"</p>")
document.write("<p>El resultado de restar ",A, " entre ",B, " es ",resta,"</p>")
document.write("<p>El resultado de sumar ",A," más ",B, " es ",suma,"</p>")
A==B
A!=B
A>B
A<B
document.write("<p>El resultado de evaluar si ",A, " y ",B, " son iguales es: ",A==B,"</p>")
document.write("<p>El resultado de evaluar si ",A, " y ",B, " son distintos es: ",A!=B,"</p>")
document.write("<p>El resultado de evaluar si ",A, " es menor que ",B, " es: ",A<B,"</p>")
document.write("<p>El resultado de evaluar si ",A, " es mayor que ",B, " es: ",A>B,"</p>")