alert("Esto lo ejecuto desde un archivo externo!");
alert("holaaaaaaa"); //estos dos alerts son los últimos en salir ya que la orden de ejecutar el js está debajo de los otros alerts