var x="Emilio"; 
var y=" 18";
var z=" Alto, moreno";
alert(x+y+z);
alert("mi nombre es " +x+ " tengo "+y+ " años y soy: "+z);
