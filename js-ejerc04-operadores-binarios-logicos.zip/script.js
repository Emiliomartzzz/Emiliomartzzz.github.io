var A= 10;
var B= 20;
document.write("<p>Que " ,A, " es menor que " ,B, " <strong> y </strong> que " ,B, " es menor que " ,A, " es: " ,A<B&&B<A, "</p>")
document.write("<p>Que " ,A, " es menor que " ,B, " <strong> o </strong> que " ,B, " es menor que " ,A, " es: " ,A<B||B<A,"</p>")
document.write("<p>Que " ,A, " es menor que " ,B, " <strong> y </strong> que " ,B, " es menor que " ,A, " es: " ,A<B&&B<A, " salvo que empleemos el operador <strong> ! </strong> delante de la expresión, entonces lo negaremos y se convertirá: " ,!(A<B&&B<A), "</p>")